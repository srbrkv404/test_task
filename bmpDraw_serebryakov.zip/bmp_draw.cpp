#include <fstream>
#include <iostream>
#include <string>


typedef struct {
    unsigned short bfType;
    unsigned int   bfSize;
    unsigned short bfReserved1;
    unsigned short bfReserved2;
    unsigned int   bfOffBits;
} BITMAPFILEHEADER;
 
typedef struct {
    unsigned int    biSize;
    int             biWidth;
    int             biHeight;
    unsigned short  biPlanes;
    unsigned short  biBitCount;
    unsigned int    biCompression;
    unsigned int    biSizeImage;
    int             biXPelsPerMeter;
    int             biYPelsPerMeter;
    unsigned int    biClrUsed;
    unsigned int    biClrImportant;
} BITMAPINFOHEADER;

typedef struct {
    unsigned short  rgbBlue;
    unsigned short  rgbGreen;
    unsigned short  rgbRed;
    unsigned short  rgbReserved;
} RGBQUAD;

class BmpImage {
        std::ifstream fileStream;
        BITMAPFILEHEADER bfh;
        BITMAPINFOHEADER bih;
        RGBQUAD **rgb;

        void displayBMP() {
            constexpr unsigned short R_IN_BLACK = 0x00, G_IN_BLACK = 0x00, B_IN_BLACK = 0x00;
            constexpr unsigned short R_IN_WHITE = 0xff, G_IN_WHITE = 0xff, B_IN_WHITE = 0xff;

            for (int i = bih.biHeight - 1; i >= 0; i--) {
                for (int j = 0; j < bih.biWidth; j++) {
                    if (rgb[i][j].rgbRed == R_IN_BLACK && rgb[i][j].rgbGreen == G_IN_BLACK &&
                             rgb[i][j].rgbBlue == B_IN_BLACK) {
                                std::cout << " ";
                    } else if (rgb[i][j].rgbRed == R_IN_WHITE && rgb[i][j].rgbGreen == G_IN_WHITE &&
                                    rgb[i][j].rgbBlue == B_IN_WHITE) {
                                        std::cout << "#";
                    } else {
                        std::cout << std::endl << "Error: invalid color." << std::endl;
                        return;
                    }
                }
                std::cout << std::endl;
            }
        }

        void closeBMP() {
            fileStream.close();

            for (int i = 0; i < bih.biHeight; i++) {
                delete[] rgb[i];
            }
            delete[] rgb;
        }

        void openBMP(const std::string *fileName) {

            constexpr unsigned int BM = 0x4d42;
            constexpr unsigned short MASK = 0xff;
            constexpr unsigned short R_OFFSET = 0;
            constexpr unsigned short G_OFFSET = 8;
            constexpr unsigned short B_OFFSET = 16;


            fileStream.open(*fileName, std::ifstream::binary);
            if (!fileStream) {
                std::cout << "Error opening file." << std::endl;
                return;
            }

            fileStream.read((char *)&bfh.bfType, sizeof(bfh.bfType));
            fileStream.read((char *)&bfh.bfSize, sizeof(bfh.bfSize));
            fileStream.read((char *)&bfh.bfReserved1, sizeof(bfh.bfReserved1));
            fileStream.read((char *)&bfh.bfReserved2, sizeof(bfh.bfReserved2));
            fileStream.read((char *)&bfh.bfOffBits, sizeof(bfh.bfOffBits));



            if (bfh.bfType != BM) {
                std::cout << "Error: this is not .bmp file." << std::endl;
            }

            fileStream.read((char *)&bih.biSize, sizeof(bih.biSize));
            fileStream.read((char *)&bih.biWidth, sizeof(bih.biWidth));
            fileStream.read((char *)&bih.biHeight, sizeof(bih.biHeight));
            fileStream.read((char *)&bih.biPlanes, sizeof(bih.biPlanes));
            fileStream.read((char *)&bih.biBitCount, sizeof(bih.biBitCount));

            
            fileStream.seekg(bfh.bfOffBits, fileStream.beg);

            rgb = new RGBQUAD *[bih.biHeight];
 
            for (int i = 0; i < bih.biHeight; i++) {
                rgb[i] = new RGBQUAD[bih.biWidth];
            }

            unsigned int color;
            for (int i = 0; i < bih.biHeight; i++) {
                for (int j = 0; j < bih.biWidth; j++) {
                    fileStream.read((char *)&color, bih.biBitCount / 8);
                    rgb[i][j].rgbRed = (color >> R_OFFSET) & MASK;
                    rgb[i][j].rgbGreen = (color >> G_OFFSET) & MASK;
                    rgb[i][j].rgbBlue = (color >> B_OFFSET) & MASK;
                }
            }
        }
    public:
        void drawBMP(const std::string *fileName) {
            openBMP(fileName);
            displayBMP();
            closeBMP();
        }
};

int main(int argc, char *argv[]) {

    constexpr int NUMOFPARAMS = 2;

    if (argc != NUMOFPARAMS) {
        std::cout << "Error: invalid command line parameters." << std::endl;
        return 0;
    }
    

    BmpImage img;
    std::string fileName = argv[1];

    img.drawBMP(&fileName);

    return 0;
}